# idli.site
## Make your website with Google Docs

## How?
- Fork or clone this repo
- On your google doc, click on File > Publish to the web; get the link.
- Paste the link in the build.py file, against the 'url' variable 
- Run build.py to generate your website
- After changing content on Google Doc, rebuild the website by running build.py again
- This pipeline can be automated with [netlify.com](https://netlify.com)

## Paid Support
- We offer paid support for setup and training. Contact us on [hi@wiosdesigns.xyz](mailto:hi@wiosdesigns.xyz) or [WhatsApp](https://wa.me/919901297970)
